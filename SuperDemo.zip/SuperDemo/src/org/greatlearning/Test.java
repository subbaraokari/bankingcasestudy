package org.greatlearning;

public class Test {

	public static void main(String[] args) {
		FullTimeEmployee fe=new FullTimeEmployee(1, "suresh", "Chennai", 10000);
		System.out.println(fe.getName()+"\t"+fe.getAddress()+"\t"+fe.getSalary());
	}

}
