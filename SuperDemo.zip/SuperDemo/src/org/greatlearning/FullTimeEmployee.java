package org.greatlearning;

public class FullTimeEmployee extends Employee{
	private int salary;
	public FullTimeEmployee() {
		// TODO Auto-generated constructor stub
	}
	public FullTimeEmployee(int eno,String name,String address,int salary) {
		super(eno,name,address);//calling parent class constructor
		this.salary = salary;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public void printEmployeeDetails()
	{
		System.out.println(super.getEno()+"\t"+super.getName()+"\t"+super.getAddress());
	}
	
}
