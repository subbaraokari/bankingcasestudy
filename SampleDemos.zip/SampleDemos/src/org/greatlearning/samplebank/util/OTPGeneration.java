package org.greatlearning.samplebank.util;

public class OTPGeneration {
	public static int generateOTP() {
		int otp=(int)(Math.random()*9000)+1000;
		return otp;
	}
	
}
