package org.greatlearning.samplebank;

import java.util.Scanner;

import org.greatlearning.samplebank.model.CustomerCredentials;
import org.greatlearning.samplebank.service.BankingService;

public class BankSimitaion {

	public static void main(String[] args) {
		BankingService bankingService = new BankingService();
		CustomerCredentials customerCredentials = new CustomerCredentials();
		customerCredentials.setBankAccountNo("123456");
		customerCredentials.setPassword("ksrao@123");
		Scanner sc = new Scanner(System.in);
		String accountNo, password;
		System.out.println("Enter the credentials");
		accountNo = sc.nextLine();
		password = sc.nextLine();
		if (customerCredentials.getBankAccountNo().equals(accountNo)
				&& customerCredentials.getPassword().equals(password)) {
			System.out.println("Welcome to Indian Bank!");
			int choice;
			do {
				System.out.println("1.Deposit");
				System.out.println("2.WithDrawl");
				System.out.println("3.Transfer");
				System.out.println("4.Logout");
				System.out.println("Please Enter your choice");
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					bankingService.deposit();
					break;
				case 2:
					bankingService.widthDrawl();
					break;
				case 3:
					bankingService.tarnsfer();
					break;
				
				default:
					System.out.println("You have been logged out from the system Please login to use services");
					break;
				}
			} while (choice <=3 && choice>0);

		}
		else
		{
			System.out.println("Invalid Credentials");
		}
	}

}
