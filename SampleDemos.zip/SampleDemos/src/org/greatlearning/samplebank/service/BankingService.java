package org.greatlearning.samplebank.service;

import java.util.Scanner;

import org.greatlearning.samplebank.util.OTPGeneration;

public class BankingService {
	Scanner sc=new Scanner(System.in);
	private int balance;
	public void deposit()
	{
		int amount;
		System.out.println("Enter the amount to deposit");
		amount=sc.nextInt();
		if(amount>0) {
			System.out.println("Balance before depositing "+balance);
			balance=balance+amount;
			System.out.println("Balance After depositing "+balance);
		}
		else
			System.out.println("Enter the correct amount");
	}
	public void widthDrawl() {
		int amount;
		System.out.println("Enter the amount you want to withdrawl");
		amount=sc.nextInt();
		if(amount>balance)
			System.out.println("Insufficient Funds");
		else
		{
			System.out.println("Balance before withdraawl "+balance);
			this.balance=this.balance-amount;
			System.out.println("Balance after withDrawl "+balance);
		}
	}
	public void tarnsfer()
	{
		int amount;
		int otp;
		int genratedOtp;
		int bankAcctNo;
		genratedOtp=OTPGeneration.generateOTP();
		System.out.println(genratedOtp);
		System.out.println("Enter the opt for verification");
		otp=sc.nextInt();
		if(otp==genratedOtp)
		{
			System.out.println("otp verification is successfull");
			System.out.println("Enter the amount and bank acctno to transfer");
			amount=sc.nextInt();
			bankAcctNo=sc.nextInt();
			if(amount>balance)
				System.out.println("Insufficient funds");
			else
			{
				System.out.println("The balance before transfer "+balance);
				balance=balance-amount;
				System.out.println("the balance after tarnsfer"+balance);
			}
		}
		else
			System.out.println("Otp is invalid Please Enter Correct OTP!");
	}
	
}
