package com.greatlearning.iitr.dsa;

public class ArrayRotation {
	//method to rotate array[]
	void leftRotate(int arr[],int ele,int size)
	{
		for(int i=0;i<ele;i++)
		{
			leftRotateByOne(arr, size);
		}
	}
	void leftRotateByOne(int arr[],int size)
	{
		int i,temp;
		temp=arr[0];
		for(i=0;i<size-1;i++)
		{
			arr[i]=arr[i+1];
		}
		arr[size-1]=temp;
	}
}
