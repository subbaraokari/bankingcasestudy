package com.greatlearning.iitr.dsa;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enter the size of an array");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		System.out.println("Enter the " + size + " elements");
		int arr[] = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		MergeSort mergeSort = new MergeSort();
		mergeSort.sort(arr, 0, arr.length - 1);
		System.out.println("The Array After sorting is ");
		for (int i = 0; i < size; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();

		/*
		 * ArrayRotation arrayRotation = new ArrayRotation(); int midElement =
		 * arr[arr.length / 2]; arrayRotation.leftRotate(arr, midElement, arr.length);
		 * System.out.println("The array After rotation is "); for (int i = 0; i < size;
		 * i++) { System.out.print(arr[i] + "  "); }
		 */

		System.out.println();
		System.out.println("enter the key");
		int key = sc.nextInt();
		BinarySearch binarySearch = new BinarySearch();
		int index = binarySearch.binarySearch(arr, 0, arr.length, key);
		System.out.println("the element is present at location " + index);

	}

}
